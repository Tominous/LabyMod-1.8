package de.labystudio.main;

import java.io.PrintStream;

public class Main
{
  public static String latest = "https://www.labymod.net/files/latest.php?update=true&ver=1.8";
  public static Frame frame;
  public static String mc = "1.8.8";
  
  public static void main(String[] args)
  {
    Frame frame = new Frame();
    frame = frame;
    new Installer(frame);
    System.exit(0);
  }
  
  public static void setStatus(String status)
  {
    frame.setStatus(status);
    System.out.println(status);
  }
}
