package de.labystudio.main;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Frame
  extends JDialog
{
  JLabel textPanel;
  
  public Frame()
  {
    setDefaultCloseOperation(1);
    setVisible(true);
    setSize(320, 95);
    setTitle("LabyMod Updater");
    setResizable(false);
    Utils.centerWindow(this, null);
    try
    {
      BufferedImage image = ImageIO.read(getClass().getResource("icon.png"));
      setIconImage(image);
    }
    catch (IOException localIOException) {}
    JPanel panel = new JPanel();
    JPanel mainPanel = new JPanel();
    this.textPanel = new JLabel();
    this.textPanel.setBounds(5, 5, 300, 300);
    this.textPanel.setHorizontalAlignment(0);
    this.textPanel.setPreferredSize(new Dimension(300, 40));
    panel.setLayout(new BorderLayout(5, 5));
    panel.add(this.textPanel);
    mainPanel.add(panel, "Center");
    setContentPane(mainPanel);
    show();
  }
  
  public void setStatus(String status)
  {
    this.textPanel.setText(status);
  }
}
