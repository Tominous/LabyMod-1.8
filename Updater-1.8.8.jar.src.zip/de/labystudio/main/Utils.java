package de.labystudio.main;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarException;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.zip.ZipException;

public class Utils
{
  public static void downloadFile(String s, File dest)
    throws IOException
  {
    URL website = new URL(s);
    URLConnection web = website.openConnection();
    web.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
    ReadableByteChannel rbc = Channels.newChannel(web.getInputStream());
    FileOutputStream fos = new FileOutputStream(dest);
    fos.getChannel().transferFrom(rbc, 0L, Long.MAX_VALUE);
    fos.close();
  }
  
  public static File getWorkingDirectory()
  {
    return getWorkingDirectory("minecraft");
  }
  
  public static File getWorkingDirectory(String applicationName)
  {
    String userHome = System.getProperty("user.home", ".");
    File workingDirectory = null;
    switch (getPlatform())
    {
    case LINUX: 
      workingDirectory = new File(userHome, '.' + applicationName + '/');
      break;
    case WINDOWS: 
      workingDirectory = new File(userHome, 
        "Library/Application Support/" + applicationName);
      break;
    case SOLARIS: 
      String applicationData = System.getenv("APPDATA");
      if (applicationData != null) {
        workingDirectory = new File(applicationData, "." + 
          applicationName + '/');
      } else {
        workingDirectory = new File(userHome, 
          '.' + applicationName + '/');
      }
      break;
    case UNKNOWN: 
      workingDirectory = new File(userHome, 
        "Library/Application Support/" + applicationName);
      break;
    case MACOS: 
      String applicationDataW = System.getenv("APPDATA");
      if (applicationDataW != null) {
        workingDirectory = new File(applicationDataW, "." + 
          applicationName + '/');
      } else {
        workingDirectory = new File(userHome, 
          '.' + applicationName + '/');
      }
      break;
    default: 
      workingDirectory = new File(userHome, applicationName + '/');
    }
    if ((!workingDirectory.exists()) && (!workingDirectory.mkdirs())) {
      throw new RuntimeException(
        "The working directory could not be created: " + 
        workingDirectory);
    }
    return workingDirectory;
  }
  
  public static ArrayList<String> getContentString(String page)
  {
    try
    {
      Main.setStatus("Downloading the information of the latest version..");
      URLConnection connection = new URL(page).openConnection();
      connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
      connection.connect();
      BufferedReader r = new BufferedReader(new InputStreamReader(connection.getInputStream(), Charset.forName("UTF-8")));
      
      String s = "";
      String line;
      while ((line = r.readLine()) != null)
      {
        String line;
        s = s + line;
      }
      ArrayList<String> list = new ArrayList();
      if (s.contains("<br>"))
      {
        String[] arrayOfString;
        int j = (arrayOfString = s.split("<br>")).length;
        for (int i = 0; i < j; i++)
        {
          String a = arrayOfString[i];
          list.add(a);
        }
      }
      System.out.println(((HttpURLConnection)connection).getResponseCode());
      return list;
    }
    catch (Exception error)
    {
      error.printStackTrace();
    }
    return new ArrayList();
  }
  
  public static void centerWindow(Component c, Component par)
  {
    if (c == null) {
      return;
    }
    Rectangle rect = c.getBounds();
    Rectangle parRect;
    Rectangle parRect;
    if ((par != null) && (par.isVisible()))
    {
      parRect = par.getBounds();
    }
    else
    {
      Dimension scrDim = Toolkit.getDefaultToolkit().getScreenSize();
      parRect = new Rectangle(0, 0, scrDim.width, scrDim.height);
    }
    int newX = parRect.x + (parRect.width - rect.width) / 2;
    int newY = parRect.y + (parRect.height - rect.height) / 2;
    if (newX < 0) {
      newX = 0;
    }
    if (newY < 0) {
      newY = 0;
    }
    c.setBounds(newX, newY, rect.width, rect.height);
  }
  
  public static boolean copyJars(ArrayList<File> mods, File destinationJar, boolean reinstalling)
  {
    try
    {
      ArrayList<String> entryList = new ArrayList();
      JarOutputStream tempJar = new JarOutputStream(new FileOutputStream(
        destinationJar));
      byte[] buffer = new byte[63];
      for (File jarFile : mods)
      {
        Main.setStatus("Install " + jarFile.getName());
        try
        {
          JarFile jar = new JarFile(jarFile);
          Enumeration<JarEntry> entries = jar.entries();
          while (entries.hasMoreElements())
          {
            JarEntry entry = new JarEntry(
              ((JarEntry)entries.nextElement()).getName());
            Main.setStatus("Copy " + entry.getName());
            if ((!entry.getName().startsWith("META-INF/")) && 
              (!entryList.contains(entry.getName())))
            {
              entryList.add(entry.getName());
              InputStream entryStream = jar
                .getInputStream(entry);
              tempJar.putNextEntry(entry);
              int bytesRead;
              while ((bytesRead = entryStream.read(buffer)) != -1)
              {
                int bytesRead;
                tempJar.write(buffer, 0, bytesRead);
              }
              entryStream.close();
              tempJar.flush();
              tempJar.closeEntry();
            }
          }
          jar.close();
        }
        catch (Exception error)
        {
          if ((((error instanceof ZipException)) || ((error instanceof JarException))) && (jarFile.getName().equals(Main.mcVersion + ".jar")) && (reinstallVersion())) {
            return copyJars(mods, destinationJar, true);
          }
          error.printStackTrace();
          return false;
        }
      }
      tempJar.close();
    }
    catch (Exception error)
    {
      error.printStackTrace();
      return false;
    }
    return true;
  }
  
  public static boolean reinstallVersion()
  {
    File directory = new File(getWorkingDirectory(), "versions/" + Main.mcVersion);
    File jarFile = new File(directory, "1.8.8.jar");
    if ((jarFile.exists()) && (!jarFile.delete()))
    {
      System.out.println("[REINSTALLING] Error while trying to delete version " + Main.mcVersion);
      return false;
    }
    try
    {
      downloadFile("https://launcher.mojang.com/mc/game/1.8.8/client/0983f08be6a4e624f5d85689d1aca869ed99c738/client.jar", jarFile);
    }
    catch (IOException e)
    {
      System.out.println("[REINSTALLING] Error while trying to download version " + Main.mcVersion + " (" + e.getMessage() + ")");
      return false;
    }
    return true;
  }
  
  public static OS getPlatform()
  {
    String osName = System.getProperty("os.name").toLowerCase();
    if (osName.contains("win")) {
      return OS.WINDOWS;
    }
    if (osName.contains("mac")) {
      return OS.MACOS;
    }
    if (osName.contains("solaris")) {
      return OS.SOLARIS;
    }
    if (osName.contains("sunos")) {
      return OS.SOLARIS;
    }
    if (osName.contains("linux")) {
      return OS.LINUX;
    }
    if (osName.contains("unix")) {
      return OS.LINUX;
    }
    return OS.UNKNOWN;
  }
  
  public static enum OS
  {
    LINUX,  SOLARIS,  WINDOWS,  MACOS,  UNKNOWN;
  }
}
