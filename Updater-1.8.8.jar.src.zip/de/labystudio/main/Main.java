package de.labystudio.main;

import java.io.PrintStream;

public class Main
{
  public static String latest = "http://www.labymod.net/files/latest.php?update=true&ver=1.8";
  public static Frame frame;
  public static String mcVersion = "1.8.8";
  public static String profileName = "LabyMod-" + mcVersion;
  public static final String mcClientUrl = "https://launcher.mojang.com/mc/game/1.8.8/client/0983f08be6a4e624f5d85689d1aca869ed99c738/client.jar";
  
  public static void main(String[] args)
  {
    System.setProperty("java.net.preferIPv4Stack", "true");
    Frame frame = new Frame();
    frame = frame;
    new Installer(frame);
    System.exit(0);
  }
  
  public static void setStatus(String status)
  {
    frame.setStatus(status);
    System.out.println(status);
  }
}
