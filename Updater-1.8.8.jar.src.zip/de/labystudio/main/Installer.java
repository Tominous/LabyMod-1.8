package de.labystudio.main;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;

public class Installer
{
  Frame frame;
  File latestJar = null;
  
  public void status(String status)
  {
    Main.setStatus(status);
  }
  
  public Installer(Frame frame)
  {
    this.frame = frame;
    if (downloadLatestVersion())
    {
      status("Start installing..");
      install();
    }
    else
    {
      status("Failed to download the latest version");
    }
  }
  
  public boolean downloadLatestVersion()
  {
    try
    {
      ArrayList<String> downloads = Utils.getContentString(Main.latest);
      if (!downloads.isEmpty())
      {
        for (String latestDownload : downloads) {
          if (latestDownload.contains("/LabyMod"))
          {
            File path = Utils.getWorkingDirectory("minecraft/LabyMod/latest/");
            if (!path.getParentFile().getParentFile().exists()) {
              return false;
            }
            if (!path.exists()) {
              path.mkdirs();
            }
            this.latestJar = new File(path.getAbsoluteFile() + "/latest.jar");
            if (this.latestJar.exists()) {
              this.latestJar.delete();
            }
            status("Downloading " + latestDownload);
            Utils.downloadFile(latestDownload, this.latestJar);
          }
          else
          {
            try
            {
              File path = Utils.getWorkingDirectory("minecraft/LabyMod/mods-" + Main.mcVersion + "/");
              if (!path.exists())
              {
                System.out.println("Can't find " + path.getAbsolutePath());
              }
              else
              {
                File install = null;
                File[] arrayOfFile;
                int j = (arrayOfFile = path.listFiles()).length;
                for (int i = 0; i < j; i++)
                {
                  File mod = arrayOfFile[i];
                  if (latestDownload.split("mods-" + Main.mcVersion + "/")[1].split("_")[0].replace(".zip", "").replace(".jar", "").equalsIgnoreCase(mod.getName().split("_")[0].replace(".zip", "").replace(".jar", ""))) {
                    if (!latestDownload.split("mods-" + Main.mcVersion + "/")[1].replace(".zip", "").replace(".jar", "").equalsIgnoreCase(mod.getName().replace(".zip", "").replace(".jar", ""))) {
                      install = mod;
                    }
                  }
                }
                if (install != null)
                {
                  install.delete();
                  status("Downloading " + latestDownload);
                  Utils.downloadFile(latestDownload, new File(path, latestDownload.split("mods-" + Main.mcVersion + "/")[1]));
                }
              }
            }
            catch (Exception error)
            {
              error.printStackTrace();
            }
          }
        }
        return true;
      }
    }
    catch (Exception error)
    {
      error.printStackTrace();
      return false;
    }
    return false;
  }
  
  public void install()
  {
    if ((this.latestJar == null) || (!this.latestJar.exists()))
    {
      status("latestJar is null");
      return;
    }
    File path = Utils.getWorkingDirectory("minecraft/LabyMod/");
    ArrayList<File> list = new ArrayList();
    File mods = new File(path.getAbsolutePath() + "/mods-" + Main.mcVersion);
    list.add(this.latestJar);
    if (mods.exists())
    {
      File[] arrayOfFile;
      int j = (arrayOfFile = mods.listFiles()).length;
      for (int i = 0; i < j; i++)
      {
        File mod = arrayOfFile[i];
        list.add(mod);
        status("Added mod " + mod.getName());
      }
    }
    File minecraft = Utils.getWorkingDirectory("minecraft/versions/" + Main.mcVersion + "/" + Main.mcVersion + ".jar");
    if (!minecraft.exists())
    {
      status("Can't find " + minecraft.getAbsolutePath());
      return;
    }
    list.add(minecraft);
    status("Install all files");
    File destinationJar = Utils.getWorkingDirectory("minecraft/versions/" + Main.profileName + "/" + Main.profileName + ".jar");
    if (destinationJar.exists())
    {
      if (destinationJar.delete())
      {
        status("Create " + destinationJar.getAbsolutePath());
        Utils.copyJars(list, destinationJar, false);
      }
      else
      {
        status("Can't delete " + destinationJar.getAbsolutePath());
      }
    }
    else {
      status("Can't find " + destinationJar.getAbsolutePath());
    }
    if ((this.latestJar.exists()) && (
      (!this.latestJar.delete()) || (!this.latestJar.getParentFile().delete()))) {
      status("Can't delete " + this.latestJar.getAbsolutePath());
    }
  }
}
